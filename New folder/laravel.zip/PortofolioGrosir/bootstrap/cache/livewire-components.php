<?php return array (
  'cart' => 'App\\Http\\Livewire\\Cart',
  'category' => 'App\\Http\\Livewire\\Category',
  'chart' => 'App\\Http\\Livewire\\Chart',
  'create' => 'App\\Http\\Livewire\\Create',
  'edit' => 'App\\Http\\Livewire\\Edit',
  'invoice' => 'App\\Http\\Livewire\\Invoice',
  'product' => 'App\\Http\\Livewire\\Product',
  'product-transaction' => 'App\\Http\\Livewire\\ProductTransaction',
  'report' => 'App\\Http\\Livewire\\Report',
  'role' => 'App\\Http\\Livewire\\Role',
);