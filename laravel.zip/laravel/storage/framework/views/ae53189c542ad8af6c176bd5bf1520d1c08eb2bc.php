<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('css/style3.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <h6 class="card-title">Timeline</h6>
                    <div id="content">
                        <ul class="timeline">
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="event" data-date="<?php echo e($product->created_at); ?>">
                                    <h3><?php echo e($product->product_id); ?></h3>
                                    <p class="text-muted">Invoice Number : <?php echo e($product->invoice_number); ?></p>
                                    <p class="text-muted">Quantity : <?php echo e($product->qty); ?></p>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\Eduwork\Protofolio\Avicena Portofolio\PortofolioGrosir\resources\views/livewire/product-transaction.blade.php ENDPATH**/ ?>