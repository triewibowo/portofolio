<div>
    <div class="mb-4">
        <h3 class="text-muted">Dashboard</h3>
    </div>

    <div class="row">
        <div class="col-md-4">
            <div class="row">
                <div class="col-md-6 mb-4">
                    <div class="card">
                        <div class="card-body position-relative">
                            <div class="icon_dash"><i class='bx bxs-wallet' id="icon"></i></div>
                            <p class="card-title">Sales Today</p>
                            <h4 class="card-text"><?php echo e('Rp ' . number_format($profit_today, 2, ',', '.')); ?></h4>
                        </div>
                        <div class="card-footer text-muted" id="card-footer">
                            <span class="fw-light" id="cashier">
                                <i class='bx bxs-calculator' id="icon2"></i> <?php echo e(Auth::user()->name); ?>

                            </span>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <div class="icon_dash"><i class='bx bx-male-female' id="icon"></i></div>
                            <p class="card-title">Guest Today</p>
                            <h4 class="card-text"><?php echo e($guest_today); ?></h4>
                        </div>
                        <div class="card-footer text-muted" id="card-footer">
                            <span class="fw-light" id="cashier">
                                <i class='bx bxs-calculator' id="icon2"></i> <?php echo e(Auth::user()->name); ?>

                            </span>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <div class="icon_dash"><i class='bx bxs-cart-alt' id="icon"></i></div>
                            <p class="card-title">Often Sale Today</p>
                            <?php if($product_today): ?>
                                <h4 class="card-text" id="cashier2"><?php echo e($product_today->name); ?></h4>
                            <?php else: ?>
                                <h4 class="card-text">Empty</h4>
                            <?php endif; ?>
                        </div>
                        <div class="card-footer text-muted" id="card-footer">
                            <?php if($product_today): ?>
                                <span class="fw-light" id="cashier">
                                    <i class='bx bxs-calculator' id="icon2"></i> <?php echo e($product_today->qty); ?>

                                </span>
                            <?php else: ?>
                                <span class="fw-light" id="cashier">
                                    <i class='bx bxs-calculator' id="icon2"></i> Empty
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <div class="icon_dash"><i class='bx bxs-package' id="icon"></i></div>
                            <p class="card-title">Total Product</p>
                            <h4 class="card-text"><?php echo e($total_product); ?></h4>
                        </div>
                        <div class="card-footer text-muted" id="card-footer">
                            <span class="fw-light" id="cashier">
                                <i class='bx bxs-calculator' id="icon2"></i> <?php echo e(Auth::user()->name); ?>

                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-5 mb-4">
            <div class="card">
                <div class="card-header text-center">
                    <h5 class="ms-4">Profit Monthly Transaction <?php echo e($year); ?></h5>
                </div>
                <div class="card-body" style="height: 19rem;">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('livewire-column-chart', ['columnChartModel' => $chart])->html();
} elseif ($_instance->childHasBeenRendered('l3719606208-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l3719606208-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3719606208-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3719606208-0');
} else {
    $response = \Livewire\Livewire::mount('livewire-column-chart', ['columnChartModel' => $chart]);
    $html = $response->html();
    $_instance->logRenderedChild('l3719606208-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>
            </div>
        </div>
        <div class="col-md-3 px-3 mb-4">
            <div class="card">
                <div class="card-header text-center">
                    <h5 class="ms-4">Monthly Transaction <?php echo e($year); ?></h5>
                </div>
                <div class="card-body" style="height: 19rem;">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('livewire-pie-chart', ['pieChartModel' => $pieChart])->html();
} elseif ($_instance->childHasBeenRendered('l3719606208-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l3719606208-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3719606208-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3719606208-1');
} else {
    $response = \Livewire\Livewire::mount('livewire-pie-chart', ['pieChartModel' => $pieChart]);
    $html = $response->html();
    $_instance->logRenderedChild('l3719606208-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-9" mb-4>
            <div class="card">
                <div class="card-header">
                    <h5 class="ms-4">Data Daily Transaction on <?php echo e($today); ?></h5>
                </div>
                <div class="card-body" style="height: 19rem;">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('livewire-column-chart', ['columnChartModel' => $colChart])->html();
} elseif ($_instance->childHasBeenRendered('l3719606208-2')) {
    $componentId = $_instance->getRenderedChildComponentId('l3719606208-2');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3719606208-2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3719606208-2');
} else {
    $response = \Livewire\Livewire::mount('livewire-column-chart', ['columnChartModel' => $colChart]);
    $html = $response->html();
    $_instance->logRenderedChild('l3719606208-2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>
            </div>
        </div>
        <div class="col-md-3 px-3" mb-4>
            <div class="card">
                <div class="card-header text-center">
                    <h5 class="ms-4">History Transaction Today</h5>
                </div>
                <div class="card-body p-4 " id="historyChart" style="height: 19rem;">
                    <?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span style="font-size: 12px"><?php echo e($item->created_at->format('h:i:s A')); ?> -
                            <?php echo e($item->invoice_number); ?> - Cashier <?php echo e($item->user->name); ?> - Total
                            <?php echo e('Rp ' . number_format($item->total, 2, ',', '.')); ?> -
                            Bayar
                            <?php echo e('Rp ' . number_format($item->pay, 2, ',', '.')); ?></span>
                        <hr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\Eduwork\Protofolio\Avicena Portofolio\PortofolioGrosir\resources\views/livewire/chart.blade.php ENDPATH**/ ?>