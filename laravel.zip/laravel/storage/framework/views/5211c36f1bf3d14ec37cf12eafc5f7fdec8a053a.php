<div>
    <div class="mb-4">
        <div class="mb-4">
            <div class="row">
                <div class="col">
                    <h3 class="text-muted">Role Permission</h3>
                </div>
                <div class="col-3">
                    <?php if(session()->has('success')): ?>
                        <div class="alert alert-success d-flex align-items-center" role="alert">
                            <svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Success:">
                                <use xlink:href="#check-circle-fill" />
                            </svg>
                            <div>
                                <?php echo e(session('success')); ?>

                            </div>
                            <button type="button" class="btn-close" id="close" data-bs-dismiss="alert"
                                aria-label="Close"></button>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <h4>Permision</h4>
            </div>
            <div class="card-body">
                <form wire:submit.prevent="roleCreate">
                    <div class="form-group">
                        <label>Role Name</label>
                        <input wire:model='name' type="text" class="form-control">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <button class="btn mt-3" type="submit"
                        style="background-color: #20B2AA; color:aliceblue;">Grant</button>
                    <button wire:click="resetField()" class="btn btn-warning mt-3" type="button">Clear</button>
                </form>
            </div>
        </div>

        <div>
            <div class="card">
                <div class="card-body">
                    <table class="table table-bordered table-hovered table-striped">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Name</th>
                                <th>Role</th>
                                <th>Email</th>
                                <th width="90px"> </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($index + 1); ?></td>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->roles); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td>
                                        <i wire:click="roleEdit(<?php echo e($user->id); ?>)" class='bx bxs-edit'
                                            data-mdb-toggle="modal" data-mdb-target="#staticBackdrop"
                                            style="font-size: 20px; color: #20B2AA; cursor: pointer;"></i>

                                        <i wire:click="roleRemove(<?php echo e($user->id); ?>)" class='bx bxs-trash'
                                            style="font-size: 20px;cursor: pointer; color:sienna;"></i>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\Eduwork\Protofolio\Avicena Portofolio\PortofolioGrosir\resources\views/livewire/role.blade.php ENDPATH**/ ?>