<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('css/style3.css')); ?>" rel="stylesheet">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
    <script defer src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
<?php $__env->stopSection(); ?>
<div>
    <div>
        <h3 class="text-muted">History</h3>
    </div>
    <div class="row d-flex justify-content-center mt-70 mb-70">
        <div class="col-md-6">
            <div class="main-card mb-3 card">
                <div class="card-body">
                    <div class="row">
                        <div class="col">
                            <h5 class="card-title">Invoice Timeline</h5>
                        </div>
                        <div class="col">
                            <div class="input-group">
                                <input wire:model="search" id="search-input" type="search" class="form-control rounded"
                                    placeholder="Search" aria-label="Search" aria-describedby="search-addon" />
                            </div>
                        </div>
                    </div>
                    <div class="scroll-area">
                        <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="vertical-timeline vertical-timeline--animate vertical-timeline--one-column">
                                <div class="vertical-timeline-item vertical-timeline-element">
                                    <div> <span class="vertical-timeline-element-icon bounce-in"> <i
                                                class="badge badge-dot badge-dot-xl badge-success"></i> </span>
                                        <div class="vertical-timeline-element-content bounce-in">
                                            <h4 class="timeline-title"><?php echo e($invoice->invoice_number); ?></h4>
                                            <p class="timeline-p">Total
                                                <?php echo e('Rp ' . number_format($invoice->total, 2, ',', '.')); ?>, Pay
                                                <?php echo e('Rp ' . number_format($invoice->pay, 2, ',', '.')); ?>, Input by
                                                <?php echo e($invoice->user->name); ?>

                                                <a href="javascript:void(0);"
                                                    data-abc="true"><?php echo e($invoice->created_at->format('h:i A')); ?></a>
                                            </p>
                                            <span
                                                class="vertical-timeline-element-date"><?php echo e($invoice->created_at->format('j F, Y')); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="main-card mb-3 card">
                <div class="card-body">
                    <div class="row">
                        <div class="col">
                            <h5 class="card-title">Product Timeline</h5>
                        </div>
                        <div class="col">
                            <div class="input-group">
                                <input wire:model="search1" id="search-input" type="search" class="form-control rounded"
                                    placeholder="Search" aria-label="Search" aria-describedby="search-addon" />
                            </div>
                        </div>
                    </div>
                    <div class="scroll-area">
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="vertical-timeline vertical-timeline--animate vertical-timeline--one-column">
                                <div class="vertical-timeline-item vertical-timeline-element">
                                    <div> <span class="vertical-timeline-element-icon bounce-in"> <i
                                                class="badge badge-dot badge-dot-xl badge-success"></i> </span>
                                        <div class="vertical-timeline-element-content bounce-in">
                                            <h4 class="timeline-title"><?php echo e($item->name); ?></h4>
                                            <p class="timeline-p">Invoice Number <?php echo e($item->invoice_number); ?>,
                                                Quantity
                                                <a href="javascript:void(0);" data-abc="true"><?php echo e($item->qty); ?></a>
                                            </p>
                                            <span
                                                class="vertical-timeline-element-date"><?php echo e($item->created_at->format('j F, Y')); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->startPush('script-custom'); ?>
    <script defer src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<?php $__env->stopPush(); ?>
<?php /**PATH D:\Eduwork\Protofolio\Avicena Portofolio\PortofolioGrosir\resources\views/livewire/invoice.blade.php ENDPATH**/ ?>